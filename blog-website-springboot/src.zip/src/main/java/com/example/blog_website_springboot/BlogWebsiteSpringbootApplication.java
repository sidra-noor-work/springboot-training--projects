package com.example.blog_website_springboot;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogWebsiteSpringbootApplication {
	public static void main(String[] args) {
		SpringApplication.run(BlogWebsiteSpringbootApplication.class, args);
	}
}
