package com.example.blogwebsitespringboot.configuration;

import com.example.blogwebsitespringboot.jwt.JwtUtil;
import com.example.blogwebsitespringboot.model.AppUser;
import com.example.blogwebsitespringboot.service.UserService;
import javax.crypto.spec.SecretKeySpec;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;


import java.util.List;

@Configuration
public class SecurityConfig {

    private final JwtUtil jwtUtil;
    private final UserService userService;

    private static final String SECRET_KEY = "your-256-bit-secret-your-256-bit-secret"; // at least 32 chars

    public SecurityConfig(final JwtUtil jwtUtil, final UserService userService) {
        this.jwtUtil = jwtUtil;
        this.userService = userService;
    }

    @Bean
    public SecurityContextLogoutHandler securityContextLogoutHandler() {
        return new SecurityContextLogoutHandler();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(final HttpSecurity http) throws Exception {
        http
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .csrf(csrf -> csrf
                        .ignoringRequestMatchers(
                                "/h2-console/**",
                                "/api/**",
                                "/auth/**"
                        )
                )
                .headers(headers -> headers.frameOptions(frame -> frame.disable()))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(
                                "/auth/**",
                                "/api/auth/**",
                                "/api/health",
                                "/h2-console/**",
                                "/css/**", "/js/**", "/v3/api-docs/**",
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/oauth2/**",
                                "/create", "/logout", "/edit/**", "/delete/**", "/home",
                                "/signup", "/auth/signup"
                        ).permitAll()
                        .requestMatchers("/blogs", "/createblog").authenticated()
                        .anyRequest().authenticated()
                )
                .exceptionHandling(ex -> ex.authenticationEntryPoint((request, response, authException) -> {
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    response.setContentType("application/json");
                    response.getWriter().write("{\"error\": \"Unauthorized\"}");
                }))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .oauth2ResourceServer(oauth2 -> oauth2
                        .jwt(jwt -> jwt.decoder(jwtDecoder()))
                )

                .oauth2Login(oauth -> oauth
                        .loginPage("/login")
                        .successHandler((request, response, authentication) -> {
                            final OAuth2User oAuth2User = (OAuth2User) authentication.getPrincipal();
                            final String username = oAuth2User.getAttribute("login");
                            userService.registerOAuthUserIfNeeded(username);
                            final AppUser user = userService.findByUsername(username);

                            final String jwt = jwtUtil.generateToken(user);
                            final boolean isLocalDev = "localhost".equals(request.getServerName());
                            final String sameSite = isLocalDev ? "Lax" : "None";
                            final String secureFlag = isLocalDev ? "" : "; Secure";

                            response.setHeader("Set-Cookie",
                                    String.format("jwt=%s; Max-Age=3600; Path=/; HttpOnly; SameSite=%s%s",
                                            jwt, sameSite, secureFlag)
                            );
                            response.sendRedirect("http://localhost:3000/createblog");
                        })
                )
                .formLogin(form -> form.disable())
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .deleteCookies("jwt")
                        .logoutSuccessHandler((request, response, authentication) -> {
                            response.setStatus(HttpServletResponse.SC_OK);
                            response.setContentType("application/json");
                            response.getWriter().write("{\"message\": \"Logged out successfully\"}");
                        })
                        .permitAll()
                );

        return http.build();
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder.withSecretKey(
                new SecretKeySpec(SECRET_KEY.getBytes(), "HmacSHA256")
        ).build();
    }

    public AuthenticationSuccessHandler oauth2SuccessHandler(final UserService userService) {
        return (request, response, authentication) -> {
            final OAuth2User oAuth2User = (OAuth2User) authentication.getPrincipal();
            final String username = oAuth2User.getAttribute("login");
            userService.registerOAuthUserIfNeeded(username);
            final AppUser user = userService.findByUsername(username);

            final String jwt = jwtUtil.generateToken(user);
            final boolean isLocalDev = "localhost".equals(request.getServerName());
            final String sameSite = isLocalDev ? "Lax" : "None";
            final String secureFlag = isLocalDev ? "" : "; Secure";

            response.setHeader("Set-Cookie",
                    String.format("jwt=%s; Max-Age=3600; Path=/; HttpOnly; SameSite=%s%s",
                            jwt, sameSite, secureFlag)
            );
            response.sendRedirect("http://localhost:3000/createblog");
        };
    }

    @Bean
    public AuthenticationManager authenticationManager(final AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public CorsFilter corsFilter() {
        return new CorsFilter(corsConfigurationSource());
    }

    public UrlBasedCorsConfigurationSource corsConfigurationSource() {
        final CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOriginPatterns(List.of("http://localhost:3000"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setExposedHeaders(List.of("Authorization", "Set-Cookie"));

        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
