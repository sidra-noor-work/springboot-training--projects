package com.example.blogwebsitespringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class BlogWebsiteSpringbootApplication {
	public static void main(final String[] args) {SpringApplication.run(BlogWebsiteSpringbootApplication.class, args);
	}
}
