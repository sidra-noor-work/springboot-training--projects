package com.example.blogwebsitespringboot;

import org.junit.jupiter.api.Test;

class BlogWebsiteSpringbootApplicationTest {

    @Test
    void mainMethodTest() {
        BlogWebsiteSpringbootApplication.main(new String[]{});
    }
}
