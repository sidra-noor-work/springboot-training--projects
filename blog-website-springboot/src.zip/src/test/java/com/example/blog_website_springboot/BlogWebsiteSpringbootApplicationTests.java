package com.example.blog_website_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogWebsiteSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
