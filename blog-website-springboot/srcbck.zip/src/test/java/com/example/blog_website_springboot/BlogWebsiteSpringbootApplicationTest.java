package com.example.blog_website_springboot;

import org.junit.jupiter.api.Test;

class BlogWebsiteSpringbootApplicationTest {

    @Test
    void mainMethodTest() {
        BlogWebsiteSpringbootApplication.main(new String[]{});
    }
}
